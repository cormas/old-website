;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;;                                           VARIABLE DEFINITION
;;                                             
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


globals
  [ count_birds 
    total_biomass 
    ]
breed
  [ harvester  ]
breed 
  [ bird ] 
breed 
  [ baby_bird ]
breed
  [ ranger ]
patches-own
  [ biomass 
    list_harvesting_history 
    patch_number
    ]
harvester-own
  [ income
    move_variable
    received           ;; variable to allocate harvest in case two or more harvesters are present at the same patch
    savings
    tribe_number
     ] 



;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;;                                             MODEL INITIALISATION 
;;                                               SETUP FUNCTIONS
;;                                             
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


to setup

  __clear-all-and-reset-ticks
;; to set up initial biomass and assign patch numbers to each of the fields
;; row one  
 ask patches with [ (pxcor = 0) and (pycor = 3) ]
         [ set patch_number 1
           set biomass  1 ] 
 ask patches with [ (pxcor = 1) and (pycor = 3) ]
         [ set patch_number 2 
           set biomass  1 ] 
 ask patches with [ (pxcor = 2) and (pycor = 3) ]
         [ set patch_number 3 
           set biomass  2 ]          
 ask patches with [ (pxcor = 3) and (pycor = 3) ]
         [ set patch_number 4 
           set biomass  1 ]         
 ask patches with [ (pxcor = 4) and (pycor = 3) ]
         [ set patch_number 5 
           set biomass  1 ] 
;; row two         
 ask patches with [ (pxcor = 0) and (pycor = 2) ]
         [ set patch_number 6 
           set biomass  2 ] 
 ask patches with [ (pxcor = 1) and (pycor = 2) ]
         [ set patch_number 7
           set biomass  0 ] 
 ask patches with [ (pxcor = 2) and (pycor = 2) ]
         [ set patch_number 8 
           set biomass  2 ]          
 ask patches with [ (pxcor = 3) and (pycor = 2) ]
         [ set patch_number 9
           set biomass  3 ]         
 ask patches with [ (pxcor = 4) and (pycor = 2) ]
         [ set patch_number 10 
           set biomass  2 ]          
;; row three         
 ask patches with [ (pxcor = 0) and (pycor = 1) ]
         [ set patch_number 11 
           set biomass  1 ] 
 ask patches with [ (pxcor = 1) and (pycor = 1) ]
         [ set patch_number 12 
           set biomass  3 ] 
 ask patches with [ (pxcor = 2) and (pycor = 1) ]
         [ set patch_number 13 
           set biomass  1 ]          
 ask patches with [ (pxcor = 3) and (pycor = 1) ]
         [ set patch_number 14 
           set biomass  2 ]         
 ask patches with [ (pxcor = 4) and (pycor = 1) ]
         [ set patch_number 15 
           set biomass  1 ] 
;; row four 
 ask patches with [ (pxcor = 0) and (pycor = 0) ]
         [ set patch_number 16 
           set biomass  1 ] 
 ask patches with [ (pxcor = 1) and (pycor = 0) ]
         [ set patch_number 17 
           set biomass  3 ] 
 ask patches with [ (pxcor = 2) and (pycor = 0) ]
         [ set patch_number 18 
           set biomass  1 ]          
 ask patches with [ (pxcor = 3) and (pycor = 0) ]
         [ set patch_number 19 
           set biomass  0 ]         
 ask patches with [ (pxcor = 4) and (pycor = 0) ]
         [ set patch_number 20 
           set biomass  2 ]         

;; colour patches according to amount of biomass         
ask patches with [ biomass = 0 ]    [ set pcolor white ]
ask patches with [ biomass = 1 ]    [ set pcolor 68    ]         
ask patches with [ biomass = 2 ]    [ set pcolor 56    ]         
ask patches with [ biomass = 3 ]    [ set pcolor 52    ]         

;; develop harvesting history of each patch
ask patches  [ set list_harvesting_history    [  0  1 ]  ]

set total_biomass ( sum [ biomass ] of patches)
  
  do-plot  

end



;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;;
;;                                             RUNTIME FUNCTIONS 
;;                                                                                           
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; scheduling
;; 1 - allocate nesting cells to the birds
;; 2 - ranger delineates protected areas (up to 3 cells)
;; 3 - households place harvesters on grid
;; 4 - model calculates breeding outcomes
;; 5 - model calculates harvested biomass
;; 6 - model calculates updated biomass per cell

to update
;; Birds and rangers from previous round disappear
 ask bird      [ die ]   ;; birds fly away at the end of each round
 ask baby_bird [ die ]   
;; ask harvester [ die ]
;; ask ranger    [ die ]   ;; 
 ask harvester  [ set income 0 ]
 tick  

 
;; 1 - allocate nesting cells to the birds 
 set count_birds (count bird + count baby_bird)
 
;; 2 - ranger delineates protected areas (up to 3 cells)
;; MANUALLY SELECTED
 
;; 3 - households randomly place harvesters on grid in first round
;; MANUALLY SELECTED

 
;; 4 - model calculates breeding outcomes
 reproduce_birds
 set count_birds (count bird + count baby_bird)
 
;; 5 - model calculates harvested biomass &  6 - model calculates updated biomass per cell
ifelse (ticks = 1)
  [ ask patches with [ count harvester-here > 0 ]   
      [ set list_harvesting_history   lput  1   list_harvesting_history ]
    ask patches with [ count harvester-here = 0 ]   
      [ set list_harvesting_history   lput  0   list_harvesting_history ] 
  ]
 [ update_harvesting_history ];; adds current round's harvester's occupation to harvesting history of patches
 
 ask patches 
   [ harvest_&_reproduce_biomass ]
 
 ask harvester 
   [ consume ]
  
;; set maximum biomass per patch to 3
 ask patches with [ biomass  > 3 ]   [ set biomass 3 ]

;; colour patches according to amount of biomass 
 ask patches with [ biomass = 0 ]    [ set pcolor white ]
 ask patches with [ biomass = 1 ]    [ set pcolor 68    ]         
 ask patches with [ biomass = 2 ]    [ set pcolor 56    ]         
 ask patches with [ biomass = 3 ]    [ set pcolor 52    ]  


 set total_biomass ( sum [ biomass ] of patches)
  
 do-plot  

end





;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;;                                          sub-routines                                                                                      
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;



;; 1 - allocate nesting cells to the birds
;; Place birds in the system based on the level of biomass available per patch
to place_birds
 ask patches with [ (biomass > 1) ] 
        [ sprout-bird   1
           [ set shape  "bird side"
             set color red 
             set size 0.3
             set heading 315
              ]] 
 ask bird [ fd 0.5 ]
end

;; 2 - ranger delineates protected areas (up to 3 cells)

;; 3 - households place harvesters on grid

;; 4 - model calculates breeding outcomes
to reproduce_birds
  ask patches [ if (( count bird-here > 0) and (count harvester-here = 0))
   [ ifelse  ( (((count neighbors with [ count harvester-here > 0 ] ) / count neighbors) <= 0.5) and 
                (((count neighbors with [ count harvester-here > 0 ] ) / count neighbors) > 0.2) )
             [ sprout-baby_bird   1
               [ set shape  "bird side"
                 set color yellow 
                 set size 0.2
                 set heading 330
              ]] 
           [  if ( ((count neighbors with [ count harvester-here > 0 ] ) / count neighbors) <= 0.2) 
             [ sprout-baby_bird   1
               [ set shape  "bird side"
                 set color white 
                 set size 0.2
                 set heading 330 ]
              sprout-baby_bird   1
               [ set shape  "bird side"
                 set color blue 
                 set size 0.2
                 set heading 320              
              ]] ]
  ] ]
 ask baby_bird [ fd 0.35 ]
end

;; 5 - model calculates harvested biomass &  6 - model calculates updated biomass per cell
;; update memory of harvesting on patches
to  update_harvesting_history
 ask patches with [ count harvester-here > 0 ]   
    [ set list_harvesting_history   lput  1          list_harvesting_history 
      set list_harvesting_history   remove-item  0   list_harvesting_history ]
 ask patches with [ count harvester-here = 0 ]   
    [ set list_harvesting_history   lput  0   list_harvesting_history 
      set list_harvesting_history   remove-item  0   list_harvesting_history ] 
end

;; new biomass amount is calculated dependent on current and past harvesting, number of harvesters per patch and current biomass per patch
to harvest_&_reproduce_biomass
;; if there are no harvesters, there is only reproduction of biomass   
  if (count harvester-here = 0)
    [ ifelse ( item 1 list_harvesting_history = 1)
        [ set biomass  biomass + 1 ]
        [  ifelse ( item 0 list_harvesting_history = 1) 
            [ set biomass  biomass + 0   ] 
            [ set biomass  biomass - 1   ] 
            ] ] 
                
;; if there are  harvesters, there is harvesting and reproduction of biomass 
   if (count harvester-here = 1)
      [ set biomass  biomass 
          ifelse (biomass < 3)
             [ ask harvester-here [ set savings (savings + biomass) 
                                    set income   biomass ] ]
             [ ask harvester-here [ set savings (savings + 2 ) 
                                    set income   2  ] ]  ]
          
   if (count harvester-here = 2)
        [ ifelse ( biomass = 3) 
                [ ask one-of harvester-here                  
                    [ set savings (savings + 2) 
                      set income   2
                      set received 1  ]
                  ask harvester-here with [ received = 0 ]
                    [ set savings (savings + 1) 
                      set income   1
                      set received 1  ]                    
                  set biomass  1 ] 
                
              [ repeat biomass  [ ask one-of harvester-here  [ set savings (savings + 1)
                                                               set income   1 ]]
                set biomass 0 ] ]
   
   if (count harvester-here > 2)  
     [ repeat biomass  [ ask one-of harvester-here  [ set savings (savings + 1) 
                                                      set income   1  ]]
       set biomass 0 ] 
 if ( biomass < 0 ) 
    [ set biomass 0]           
end


;; Harvesters consume one unit of savings each round
to consume
  set savings savings - 1
end





;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;;                                         Drawing Functions                                                                                    
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;                                           HARVESTERS
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; The mouse can be used to manually place harvesters in the field. This done by using the draw buttons and then clicking with 
;; the mouse in the graphic window. Immediately a harvester is drawn on that patch. 
to Tribe_1
  if mouse-down?     ;; Reports true or false to indicate whether mouse button is down
   [ ask patch mouse-xcor mouse-ycor
         [  sprout-harvester 1 [ 
             set shape  "person"
             set color black 
             set size 0.3
             set tribe_number 1
             rt (random-float 360 ) 
             set received 0  ]
         ask harvester-here  [ fd  0.2 ]         
         ]]
end

to Tribe_2
  if mouse-down?     ;; Reports true or false to indicate whether mouse button is down
   [ ask patch mouse-xcor mouse-ycor
         [  sprout-harvester 1 [ 
             set shape  "person"
             set color pink 
             set size 0.3
             set tribe_number 2
             rt (random-float 360 ) 
             set received 0  ]
         ask harvester-here  [ fd  0.2 ]         
         ]]
end

to Tribe_3
  if mouse-down?     ;; Reports true or false to indicate whether mouse button is down
   [ ask patch mouse-xcor mouse-ycor
         [  sprout-harvester 1 [ 
             set shape  "person"
             set color yellow 
             set size 0.3
             set tribe_number 3
             rt (random-float 360 ) 
             set received 0  ]
         ask harvester-here  [ fd  0.2 ]         
         ]]
end

to Tribe_4
  if mouse-down?     ;; Reports true or false to indicate whether mouse button is down
   [ ask patch mouse-xcor mouse-ycor
         [  sprout-harvester 1 [ 
             set shape  "person"
             set color green 
             set size 0.3
             set tribe_number 4
             rt (random-float 360 ) 
             set received 0  ]
         ask harvester-here  [ fd  0.2 ]         
         ]]
end

to Tribe_5
  if mouse-down?     ;; Reports true or false to indicate whether mouse button is down
   [ ask patch mouse-xcor mouse-ycor
         [  sprout-harvester 1 [ 
             set shape  "person"
             set color brown
             set size 0.3
             set tribe_number 5
             rt (random-float 360 ) 
             set received 0  ]
         ask harvester-here  [ fd  0.2 ]         
         ] ]
end

to Tribe_6
  if mouse-down?     ;; Reports true or false to indicate whether mouse button is down
   [ ask patch mouse-xcor mouse-ycor
         [  sprout-harvester 1 [ 
             set shape  "person"
             set color blue 
             set size 0.3
             set tribe_number 6
             rt (random-float 360 ) 
             set received 0  ]
         ask harvester-here  [ fd  0.2 ]         
         ] ]
end

to Tribe_7
  if mouse-down?     ;; Reports true or false to indicate whether mouse button is down
   [ ask patch mouse-xcor mouse-ycor
         [  sprout-harvester 1 [ 
             set shape  "person"
             set color 125 
             set size 0.3
             set tribe_number 7
             rt (random-float 360 ) 
             set received 0  ]
         ask harvester-here  [ fd  0.2 ]         
         ]]
end

to Tribe_8
  if mouse-down?     ;; Reports true or false to indicate whether mouse button is down
   [ ask patch mouse-xcor mouse-ycor
         [  sprout-harvester 1 [ 
             set shape  "person"
             set color 25 
             set size 0.3
             set tribe_number 8
             rt (random-float 360 ) 
             set received 0  ]
         ask harvester-here  [ fd  0.2 ]         
         ]]
end

to Tribe_9
  if mouse-down?     ;; Reports true or false to indicate whether mouse button is down
   [ ask patch mouse-xcor mouse-ycor
         [  sprout-harvester 1 [ 
             set shape  "person"
             set color red 
             set size 0.3
             set tribe_number 9
             rt (random-float 360 ) 
             set received 0  ]
            ask harvester-here  [ fd  0.2 ]
           ]]
end

to Tribe_10
  if mouse-down?     ;; Reports true or false to indicate whether mouse button is down
   [ ask patch mouse-xcor mouse-ycor
         [  sprout-harvester 1 [ 
             set shape  "person"
             set color 85 
             set size 0.3
             set tribe_number 10
             rt (random-float 360 ) 
             set received 0  ]
         ask harvester-here  [ fd  0.2 ]
         ] ]
end

to clear
  ask harvester [ die ]
  ask ranger    [ die ]
  ask bird      [ die ]   ;; birds fly away at the end of each round
  ask baby_bird [ die ]   
end


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;                                           RANGERS
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

to delineate_protection
  if mouse-down?     ;; Reports true or false to indicate whether mouse button is down
   [ ask patch mouse-xcor mouse-ycor
          [  sprout-ranger   1
           [ set shape  "person construction"
             set size 0.3
             set color white
             set heading 45 ]
          ask ranger-here [ fd  0.5 ]  ;;; move rangers to upper right corner of patch       
           ]]          
end

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;;                                          Graphs                                                                                     
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

to do-plot   
    set-current-plot "Total_biomass"
    set-current-plot-pen "TB" 
      plot total_biomass

   set-current-plot "Count_birds"
    set-current-plot-pen "CB" 
      plot count_birds
end 
@#$#@#$#@
GRAPHICS-WINDOW
354
35
702
336
-1
-1
67.6
1
10
1
1
1
0
0
0
1
0
4
0
3
0
0
1
ticks
30.0

BUTTON
20
34
83
67
NIL
setup
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

MONITOR
20
78
83
123
Rounds
ticks
17
1
11

PLOT
817
37
1035
221
Total_biomass
NIL
NIL
0.0
10.0
0.0
10.0
true
false
"" ""
PENS
"TB" 1.0 0 -16777216 true "plot total_biomass" "plot total_biomass"

MONITOR
130
134
234
179
Total biomass
total_biomass
17
1
11

BUTTON
82
34
180
67
update_one
update
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

MONITOR
20
184
120
229
Count birds
count_birds
17
1
11

PLOT
817
230
1035
410
Count_birds
NIL
NIL
0.0
10.0
0.0
10.0
true
false
"" ""
PENS
"CB" 1.0 0 -16777216 false "plot count_birds" "plot count_birds"

MONITOR
20
134
122
179
Count harvesters
count harvester
17
1
11

MONITOR
129
184
232
229
Count chicks
count baby_bird
17
1
11

BUTTON
19
465
92
498
NIL
Tribe_1
T
1
T
PATCH
NIL
NIL
NIL
NIL
1

TEXTBOX
18
448
308
476
To place harvesters of the 10 tribes in the field
11
0.0
1

BUTTON
104
465
177
498
NIL
Tribe_2
T
1
T
PATCH
NIL
NIL
NIL
NIL
1

BUTTON
189
465
262
498
NIL
Tribe_3
T
1
T
PATCH
NIL
NIL
NIL
NIL
1

BUTTON
273
465
346
498
NIL
Tribe_4
T
1
T
PATCH
NIL
NIL
NIL
NIL
1

BUTTON
355
467
428
500
NIL
Tribe_5
T
1
T
PATCH
NIL
NIL
NIL
NIL
1

BUTTON
440
467
513
500
NIL
Tribe_6
T
1
T
PATCH
NIL
NIL
NIL
NIL
1

BUTTON
523
467
596
500
NIL
Tribe_7
T
1
T
PATCH
NIL
NIL
NIL
NIL
1

BUTTON
605
467
678
500
NIL
Tribe_8
T
1
T
PATCH
NIL
NIL
NIL
NIL
1

BUTTON
688
467
761
500
NIL
Tribe_9
T
1
T
PATCH
NIL
NIL
NIL
NIL
1

BUTTON
772
468
852
501
NIL
Tribe_10
T
1
T
PATCH
NIL
NIL
NIL
NIL
1

MONITOR
20
554
92
599
Savings
sum [ savings ] of harvester with [ tribe_number = 1 ]
17
1
11

MONITOR
105
554
178
599
Savings
sum [ savings] of harvester with [ tribe_number = 2 ]
17
1
11

MONITOR
192
554
263
599
Savings
sum [ savings] of harvester with [ tribe_number = 3 ]
17
1
11

MONITOR
274
554
344
599
Savings
sum [ savings] of harvester with [ tribe_number = 4 ]
17
1
11

MONITOR
355
554
427
599
Savings
sum [ savings] of harvester with [ tribe_number = 5 ]
17
1
11

MONITOR
443
554
515
599
Savings
sum [ savings] of harvester with [ tribe_number = 6 ]
17
1
11

MONITOR
524
555
595
600
Savings
sum [ savings] of harvester with [ tribe_number = 7 ]
17
1
11

MONITOR
608
554
679
599
Savings
sum [ savings] of harvester with [ tribe_number = 8 ]
17
1
11

MONITOR
692
554
762
599
Savings
sum [ savings] of harvester with [ tribe_number = 9 ]
17
1
11

MONITOR
772
555
852
600
Savings
sum [ savings] of harvester with [ tribe_number = 10 ]
17
1
11

BUTTON
20
408
97
442
Ranger
delineate_protection
T
1
T
PATCH
NIL
NIL
NIL
NIL
1

TEXTBOX
20
392
170
410
To delineate protected areas
11
0.0
1

MONITOR
20
504
93
549
Income
sum [ income ] of harvester with [ tribe_number = 1 ]
17
1
11

MONITOR
105
504
178
549
Income
sum [ income ] of harvester with [ tribe_number = 2 ]
17
1
11

MONITOR
190
504
263
549
Income
sum [ income] of harvester with [ tribe_number = 3 ]
17
1
11

MONITOR
274
504
346
549
Income
sum [ income ] of harvester with [ tribe_number = 4 ]
17
1
11

MONITOR
355
504
429
549
Income
sum [ income ] of harvester with [ tribe_number = 5 ]
17
1
11

MONITOR
442
504
515
549
Income
sum [ income ] of harvester with [ tribe_number = 6 ]
17
1
11

MONITOR
524
504
597
549
Income
sum [ income ] of harvester with [ tribe_number = 6 ]
17
1
11

MONITOR
607
504
680
549
Income
sum [ income ] of harvester with [ tribe_number = 8 ]
17
1
11

MONITOR
690
504
762
549
Income
sum [ income ] of harvester with [ tribe_number = 9 ]
17
1
11

MONITOR
772
505
852
550
Income
sum [ income ] of harvester with [ tribe_number = 10 ]
17
1
11

BUTTON
22
297
95
331
Clear
clear
NIL
1
T
TURTLE
NIL
NIL
NIL
NIL
1

BUTTON
22
353
96
387
Place_birds
place_birds
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

TEXTBOX
22
337
210
360
Place birds in space
11
0.0
1

TEXTBOX
23
252
343
321
Before each round: 1- clear the field, 2-place the birds, 3-delineate the protected ares, 4- place harvesters in the field and then press update_one
11
0.0
1

TEXTBOX
23
10
622
66
!!! BEFORE STARTING THE SIMULATION, BE SURE TO ADJUST THE SPEED OF THE SIMULATION TO SLOW !!!
11
0.0
1

@#$#@#$#@
## WHAT IS IT?

(a general understanding of what the model is trying to show or explain)

## HOW IT WORKS

(what rules the agents use to create the overall behavior of the model)

## HOW TO USE IT

(how to use the model, including a description of each of the items in the Interface tab)

## THINGS TO NOTICE

(suggested things for the user to notice while running the model)

## THINGS TO TRY

(suggested things for the user to try to do (move sliders, switches, etc.) with the model)

## EXTENDING THE MODEL

(suggested things to add or change in the Code tab to make the model more complicated, detailed, accurate, etc.)

## NETLOGO FEATURES

(interesting or unusual features of NetLogo that the model uses, particularly in the Code tab; or where workarounds were needed for missing features)

## RELATED MODELS

(models in the NetLogo Models Library and elsewhere which are of related interest)

## CREDITS AND REFERENCES

(a reference to the model's URL on the web if it has one, as well as any other necessary credits, citations, and links)
@#$#@#$#@
default
true
0
Polygon -7500403 true true 150 5 40 250 150 205 260 250

airplane
true
0
Polygon -7500403 true true 150 0 135 15 120 60 120 105 15 165 15 195 120 180 135 240 105 270 120 285 150 270 180 285 210 270 165 240 180 180 285 195 285 165 180 105 180 60 165 15

arrow
true
0
Polygon -7500403 true true 150 0 0 150 105 150 105 293 195 293 195 150 300 150

bird side
false
0
Polygon -7500403 true true 0 120 45 90 75 90 105 120 150 120 240 135 285 120 285 135 300 150 240 150 195 165 255 195 210 195 150 210 90 195 60 180 45 135
Circle -16777216 true false 38 98 14

box
false
0
Polygon -7500403 true true 150 285 285 225 285 75 150 135
Polygon -7500403 true true 150 135 15 75 150 15 285 75
Polygon -7500403 true true 15 75 15 225 150 285 150 135
Line -16777216 false 150 285 150 135
Line -16777216 false 150 135 15 75
Line -16777216 false 150 135 285 75

bug
true
0
Circle -7500403 true true 96 182 108
Circle -7500403 true true 110 127 80
Circle -7500403 true true 110 75 80
Line -7500403 true 150 100 80 30
Line -7500403 true 150 100 220 30

butterfly
true
0
Polygon -7500403 true true 150 165 209 199 225 225 225 255 195 270 165 255 150 240
Polygon -7500403 true true 150 165 89 198 75 225 75 255 105 270 135 255 150 240
Polygon -7500403 true true 139 148 100 105 55 90 25 90 10 105 10 135 25 180 40 195 85 194 139 163
Polygon -7500403 true true 162 150 200 105 245 90 275 90 290 105 290 135 275 180 260 195 215 195 162 165
Polygon -16777216 true false 150 255 135 225 120 150 135 120 150 105 165 120 180 150 165 225
Circle -16777216 true false 135 90 30
Line -16777216 false 150 105 195 60
Line -16777216 false 150 105 105 60

car
false
0
Polygon -7500403 true true 300 180 279 164 261 144 240 135 226 132 213 106 203 84 185 63 159 50 135 50 75 60 0 150 0 165 0 225 300 225 300 180
Circle -16777216 true false 180 180 90
Circle -16777216 true false 30 180 90
Polygon -16777216 true false 162 80 132 78 134 135 209 135 194 105 189 96 180 89
Circle -7500403 true true 47 195 58
Circle -7500403 true true 195 195 58

circle
false
0
Circle -7500403 true true 0 0 300

circle 2
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240

cow
false
0
Polygon -7500403 true true 200 193 197 249 179 249 177 196 166 187 140 189 93 191 78 179 72 211 49 209 48 181 37 149 25 120 25 89 45 72 103 84 179 75 198 76 252 64 272 81 293 103 285 121 255 121 242 118 224 167
Polygon -7500403 true true 73 210 86 251 62 249 48 208
Polygon -7500403 true true 25 114 16 195 9 204 23 213 25 200 39 123

cylinder
false
0
Circle -7500403 true true 0 0 300

dot
false
0
Circle -7500403 true true 90 90 120

face happy
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 255 90 239 62 213 47 191 67 179 90 203 109 218 150 225 192 218 210 203 227 181 251 194 236 217 212 240

face neutral
false
0
Circle -7500403 true true 8 7 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Rectangle -16777216 true false 60 195 240 225

face sad
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 168 90 184 62 210 47 232 67 244 90 220 109 205 150 198 192 205 210 220 227 242 251 229 236 206 212 183

fish
false
0
Polygon -1 true false 44 131 21 87 15 86 0 120 15 150 0 180 13 214 20 212 45 166
Polygon -1 true false 135 195 119 235 95 218 76 210 46 204 60 165
Polygon -1 true false 75 45 83 77 71 103 86 114 166 78 135 60
Polygon -7500403 true true 30 136 151 77 226 81 280 119 292 146 292 160 287 170 270 195 195 210 151 212 30 166
Circle -16777216 true false 215 106 30

flag
false
0
Rectangle -7500403 true true 60 15 75 300
Polygon -7500403 true true 90 150 270 90 90 30
Line -7500403 true 75 135 90 135
Line -7500403 true 75 45 90 45

flower
false
0
Polygon -10899396 true false 135 120 165 165 180 210 180 240 150 300 165 300 195 240 195 195 165 135
Circle -7500403 true true 85 132 38
Circle -7500403 true true 130 147 38
Circle -7500403 true true 192 85 38
Circle -7500403 true true 85 40 38
Circle -7500403 true true 177 40 38
Circle -7500403 true true 177 132 38
Circle -7500403 true true 70 85 38
Circle -7500403 true true 130 25 38
Circle -7500403 true true 96 51 108
Circle -16777216 true false 113 68 74
Polygon -10899396 true false 189 233 219 188 249 173 279 188 234 218
Polygon -10899396 true false 180 255 150 210 105 210 75 240 135 240

house
false
0
Rectangle -7500403 true true 45 120 255 285
Rectangle -16777216 true false 120 210 180 285
Polygon -7500403 true true 15 120 150 15 285 120
Line -16777216 false 30 120 270 120

leaf
false
0
Polygon -7500403 true true 150 210 135 195 120 210 60 210 30 195 60 180 60 165 15 135 30 120 15 105 40 104 45 90 60 90 90 105 105 120 120 120 105 60 120 60 135 30 150 15 165 30 180 60 195 60 180 120 195 120 210 105 240 90 255 90 263 104 285 105 270 120 285 135 240 165 240 180 270 195 240 210 180 210 165 195
Polygon -7500403 true true 135 195 135 240 120 255 105 255 105 285 135 285 165 240 165 195

line
true
0
Line -7500403 true 150 0 150 300

line half
true
0
Line -7500403 true 150 0 150 150

pentagon
false
0
Polygon -7500403 true true 150 15 15 120 60 285 240 285 285 120

person
false
0
Circle -7500403 true true 110 5 80
Polygon -7500403 true true 105 90 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285 180 195 195 90
Rectangle -7500403 true true 127 79 172 94
Polygon -7500403 true true 195 90 240 150 225 180 165 105
Polygon -7500403 true true 105 90 60 150 75 180 135 105

person construction
false
0
Rectangle -7500403 true true 123 76 176 95
Polygon -1 true false 105 90 60 195 90 210 115 162 184 163 210 210 240 195 195 90
Polygon -13345367 true false 180 195 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285
Circle -7500403 true true 110 5 80
Line -16777216 false 148 143 150 196
Rectangle -16777216 true false 116 186 182 198
Circle -1 true false 152 143 9
Circle -1 true false 152 166 9
Rectangle -16777216 true false 179 164 183 186
Polygon -955883 true false 180 90 195 90 195 165 195 195 150 195 150 120 180 90
Polygon -955883 true false 120 90 105 90 105 165 105 195 150 195 150 120 120 90
Rectangle -16777216 true false 135 114 150 120
Rectangle -16777216 true false 135 144 150 150
Rectangle -16777216 true false 135 174 150 180
Polygon -955883 true false 105 42 111 16 128 2 149 0 178 6 190 18 192 28 220 29 216 34 201 39 167 35
Polygon -6459832 true false 54 253 54 238 219 73 227 78
Polygon -16777216 true false 15 285 15 255 30 225 45 225 75 255 75 270 45 285

petals
false
0
Circle -7500403 true true 117 12 66
Circle -7500403 true true 116 221 67
Circle -7500403 true true 41 41 67
Circle -7500403 true true 11 116 67
Circle -7500403 true true 41 191 67
Circle -7500403 true true 191 191 67
Circle -7500403 true true 221 116 67
Circle -7500403 true true 191 41 67
Circle -7500403 true true 60 60 180

plant
false
0
Rectangle -7500403 true true 135 90 165 300
Polygon -7500403 true true 135 255 90 210 45 195 75 255 135 285
Polygon -7500403 true true 165 255 210 210 255 195 225 255 165 285
Polygon -7500403 true true 135 180 90 135 45 120 75 180 135 210
Polygon -7500403 true true 165 180 165 210 225 180 255 120 210 135
Polygon -7500403 true true 135 105 90 60 45 45 75 105 135 135
Polygon -7500403 true true 165 105 165 135 225 105 255 45 210 60
Polygon -7500403 true true 135 90 120 45 150 15 180 45 165 90

sheep
false
15
Circle -1 true true 203 65 88
Circle -1 true true 70 65 162
Circle -1 true true 150 105 120
Polygon -7500403 true false 218 120 240 165 255 165 278 120
Circle -7500403 true false 214 72 67
Rectangle -1 true true 164 223 179 298
Polygon -1 true true 45 285 30 285 30 240 15 195 45 210
Circle -1 true true 3 83 150
Rectangle -1 true true 65 221 80 296
Polygon -1 true true 195 285 210 285 210 240 240 210 195 210
Polygon -7500403 true false 276 85 285 105 302 99 294 83
Polygon -7500403 true false 219 85 210 105 193 99 201 83

square
false
0
Rectangle -7500403 true true 30 30 270 270

square 2
false
0
Rectangle -7500403 true true 30 30 270 270
Rectangle -16777216 true false 60 60 240 240

star
false
0
Polygon -7500403 true true 151 1 185 108 298 108 207 175 242 282 151 216 59 282 94 175 3 108 116 108

target
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240
Circle -7500403 true true 60 60 180
Circle -16777216 true false 90 90 120
Circle -7500403 true true 120 120 60

tree
false
0
Circle -7500403 true true 118 3 94
Rectangle -6459832 true false 120 195 180 300
Circle -7500403 true true 65 21 108
Circle -7500403 true true 116 41 127
Circle -7500403 true true 45 90 120
Circle -7500403 true true 104 74 152

triangle
false
0
Polygon -7500403 true true 150 30 15 255 285 255

triangle 2
false
0
Polygon -7500403 true true 150 30 15 255 285 255
Polygon -16777216 true false 151 99 225 223 75 224

truck
false
0
Rectangle -7500403 true true 4 45 195 187
Polygon -7500403 true true 296 193 296 150 259 134 244 104 208 104 207 194
Rectangle -1 true false 195 60 195 105
Polygon -16777216 true false 238 112 252 141 219 141 218 112
Circle -16777216 true false 234 174 42
Rectangle -7500403 true true 181 185 214 194
Circle -16777216 true false 144 174 42
Circle -16777216 true false 24 174 42
Circle -7500403 false true 24 174 42
Circle -7500403 false true 144 174 42
Circle -7500403 false true 234 174 42

turtle
true
0
Polygon -10899396 true false 215 204 240 233 246 254 228 266 215 252 193 210
Polygon -10899396 true false 195 90 225 75 245 75 260 89 269 108 261 124 240 105 225 105 210 105
Polygon -10899396 true false 105 90 75 75 55 75 40 89 31 108 39 124 60 105 75 105 90 105
Polygon -10899396 true false 132 85 134 64 107 51 108 17 150 2 192 18 192 52 169 65 172 87
Polygon -10899396 true false 85 204 60 233 54 254 72 266 85 252 107 210
Polygon -7500403 true true 119 75 179 75 209 101 224 135 220 225 175 261 128 261 81 224 74 135 88 99

wheel
false
0
Circle -7500403 true true 3 3 294
Circle -16777216 true false 30 30 240
Line -7500403 true 150 285 150 15
Line -7500403 true 15 150 285 150
Circle -7500403 true true 120 120 60
Line -7500403 true 216 40 79 269
Line -7500403 true 40 84 269 221
Line -7500403 true 40 216 269 79
Line -7500403 true 84 40 221 269

wolf
false
0
Polygon -16777216 true false 253 133 245 131 245 133
Polygon -7500403 true true 2 194 13 197 30 191 38 193 38 205 20 226 20 257 27 265 38 266 40 260 31 253 31 230 60 206 68 198 75 209 66 228 65 243 82 261 84 268 100 267 103 261 77 239 79 231 100 207 98 196 119 201 143 202 160 195 166 210 172 213 173 238 167 251 160 248 154 265 169 264 178 247 186 240 198 260 200 271 217 271 219 262 207 258 195 230 192 198 210 184 227 164 242 144 259 145 284 151 277 141 293 140 299 134 297 127 273 119 270 105
Polygon -7500403 true true -1 195 14 180 36 166 40 153 53 140 82 131 134 133 159 126 188 115 227 108 236 102 238 98 268 86 269 92 281 87 269 103 269 113

x
false
0
Polygon -7500403 true true 270 75 225 30 30 225 75 270
Polygon -7500403 true true 30 75 75 30 270 225 225 270

@#$#@#$#@
NetLogo 5.1.0
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
default
0.0
-0.2 0 0.0 1.0
0.0 1 1.0 0.0
0.2 0 0.0 1.0
link direction
true
0
Line -7500403 true 150 150 90 180
Line -7500403 true 150 150 210 180

@#$#@#$#@
0
@#$#@#$#@
