VisualWorks(R) 3.0 "Goodies" ReadMe
Copyright (c) 1998 ObjectShare, Inc.  All rights reserved.

The "goodies" in this directory are extensions to VisualWorks.
Those in the "other" directory are 3rd party goodies in the public
domain that we think are either very useful or fun.
Those in the "parc" directory are by ObjectShare.
The following is a brief description of each.

In the "other/" directory:
            CoolImage--an image (icon) editor
            Gremlin--guess :)
            HotDraw--a framework for 2D drawing editors
            ProgressWidget--a tool for creating a "% done" widget
            RefactoringBrowser--an alternate Smalltalk
                Browser that supports class hierarchy arrangements
            Regex--a regular expression matching tool
            SmallWalker--a web browser written in VisualWorks

In the "parc/" directory:
            BrowserChangeSetEditing--allows add and remove of specific
				changes from current change set using the browser
            ColorEditing--allows user-definable color coding of source code
            FlyByHelp--adds pop-up help for widgets for
                VisualWorks applications
            GFST--a graphics framework that supports rapid
                construction of graphical diagrams and animations
            JuggleButtons--a tool to swap with middle and
                right mouse buttons on Windows
            ProgrammingHacks--usability extensions to the Smalltalk Browser
            STAMP--an email program written in VisualWorks
            VRGoodies--includes UI Building enhancements
                (including a Form Generator and UIDefiner
                upgrade) and UI Framework enhancements
                (subclasses of Application Model that provide
                additional functionality)
            WorkSpaceOrganizer--a tool to maintain a
                hierarchically-organized list of Workspaces


These "goodies" are provided to you without warranty and
without support.  Use at your own discretion.

02/05/98  py
