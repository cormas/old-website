VisualWorks(R) Non-Commercial 3.0 ReadMe
Copyright (c) ObjectShare, Inc. 1998. All rights reserved.


PURPOSE OF THIS README FILE

This README identifies the distribution contents and directory 
structure of this release of VisualWorks Non-Commercial.  For a 
description of changes made in this release, refer to the 
VisualWorks Non-Commercial 3.0 Release Notes file (vwrn.pdf) 
in the doc directory.  For installation instructions for this 
release, refer to the VisualWorks Non-Commercial 3.0 Installation 
Guide (vwig.pdf) in the doc directory.

Note on .pdf document files: Refer to the readme.txt in the doc/ 
directory for more information on reading .pdf files.


DISTRIBUTION CONTENTS

readme.txt   (this document)
license.txt  (VisualWorks Non-Commercial license)

vwnc30/  (VisualWorks Non-Commercial 3.0 release directory; 
          although only .pcl parcel files are listed, there is also 
          an accompanying .pst source file for each)
    bin/  (empty directory for executable files)

    doc/
        vwadg.pdf  (VisualWorks Application Developer's Guide 
                    in Acrobat format)
        vwbgug.pdf (Business Graphics User's Guide in Acrobat format)
        vwig.pdf   (VisualWorks Non-Commercial Installation Guide 
                    in Acrobat format)
        vwrn.pdf   (VisualWorks Non-Commercial Release Notes in 
                    Acrobat format)
        SysDeps.pdf  ("events" document in Acrobat format)
        ChangeList.txt  (change list features)

    image/
        visualnc.im
        visualnc.sou

    parcels/
        BGOK.pcl
        BOSS.pcl
        Database.pcl
        Headless.pcl
        Help.pcl
        ImageMaker.pcl
        Lens.pcl,
        MacExtras.pcl
        SysDeps.pcl
        UIPainter.pcl

        removals/  (removal scripts for Image making)
            advbase.rm, db2dkit.rm, lensgen.rm, orcompat.rm, 
            tablview.rm, advcmpat.rm, db2ifc.rm, lenstool.rm, 
            os2look.rm, uibase.rm, advex.rm, dbcompat.rm, 
            maclook.rm, printing.rm, uitool.rm, advtool.rm, 
            dsettool.rm, mtdflook.rm, progex.rm, winlook.rm, 
            bgokex.rm, dsetview.rm, ntbktool.rm, progtool.rm, 
            xtrnbase.rm, bgoktool.rm, exdi.rm, ntbkview.rm, 
            sycompat.rm, xtrntool.rm, bgokview.rm, exditool.rm, 
            oldview.rm, sydkit.rm, boss.rm, help.rm, oradkit.rm, 
            syifc.rm, compiler.rm, lensapp.rm, oraifc.rm, 
            sylens.rm, dand.rm, lensbase.rm, oralens.rm, 
            tabltool.rm

    online/
        cookbook.hlp
        examples/
            Adapt1.st, Adapt2.st, Adapt3.st, Adapt4.st, Adapt5.st, 
            Adapt6.st, Amortize.st, Button.st, Color.st, Combo.st, 
            ComboCon.st, Cursor.st, Cust1.st, Cust2.st, CustVw1, 
            CustVw2.st, DB1.st, DB1add.st, DB1delet.st, 
            Dataset1.st, Dataset2.st, Dataset3.st, Dataset4.st, 
            Depend.st, Dialog.st, DragDrop.st, Editor1.st, 
            Editor2.st, Employee.st, FldConn.st, FldFilt.st, 
            FldMenu.st, FldSel.st, FldType.st, FldVal1.st, 
            FldVal2.st, FldValid.st, Font1.st, Font2.st, Hide.st, 
            Line.st, List1.st, List2.st, LoanCalc.st, Logo.st, 
            MenuCmd.st, MenuEdit.st, MenuMod., MenuSwap.st, 
            MenuVal.st, Move.st, Notebk1, Notebk2.st, Notebk3.st, 
            Notebk4.st, Notebk5.st, Point., PrefCust.st, Size1.st, 
            Size2.st, Size3.st, SkCon1.st, SkCon2.st, SkView1.st,
            SkView2.st, Sketch.st, Slider1.st, Slider2.st, 
            Subcan1.st, Subcan2.st, Subcan3.st, Table1.st, 
            Table2.st, Table3.st, TimeType.st

    compat/
        OldViews.pcl     (support for old-style views)
        OldLauncher.pcl  (support for the (very) old menu-like launcher)
        UIMenuEditor.pcl (old menu editor)

    goodies/
        readme.txt
        other/ 
            CoolImage.pcl  (image [icon] editor)
            Gremlin.pcl
            HotDraw.pcl
            HotDrawAnimatedExamples.pcl
            HotDrawAnimationFramework.pcl
            HotDrawDrawingInspector.pcl
            HotDrawFramework.pcl
            HotDrawHotPaint.pcl
            HotDrawPERTChart.pcl
            HotDrawToolDevelopment.pcl
            ProgressWidget.pcl
            RefactoringBrowser.pcl
            Regex.pcl
            SmallWalker.pcl

        parc/
            BrowserChangeSetEditing.pcl
            ColorEditing.pcl  (color syntax-driven editor)
            FlyByHelp.pcl
            FlyByHelpPreLoad.pcl
            GFST-Base.pcl
            GFST-Demo.pcl
            GFST-GraphLayout.pcl
            GFST-OrgChart.pcl
            GFST-VisualInspector.pcl
            gfstvw.hlp
            JuggleButtons.pcl
            ProgrammingHacks.pcl
            STAMP.pcl
            VRGoodies.pcl  (tool goodies)
            VRGoodies.pdf  (VR Goodies documentation in Acrobat 
                            format)
            VRLens.pcl     (lens and tools extensions)
            VRPainter.pcl
            VRPainterPrereq.pcl
            VRPainterPrereq2.pcl
            VRUIPainter.pcl
            WorkSpaceOrganizer.pcl

            resource/
                3d.bmp, 3dmask.bmp, About.bmp, About16.bmp, 
                Aboutmsk.bmp, Arrow.bmp, Bezier.bmp, Btofrnt.bmp, 
                Button.bmp, Calendar.bmp, Calmask.bmp, Clsfig.bmp, 
                Comps.bmp, Dwngmask.bmp, Dwngtool.bmp, 
                Editfld.bmp, Edittext.bmp, Edittool.bmp, 
                Ellipse.bmp, Etcat.bmp, Gofigure.Ico, Graphs.bmp, 
                Grphmask.bmp, Help.bmp, Helpmask.bmp, Image.bmp, 
                Inspect.bmp, Inspmask.bmp, Lendmask.bmp, Line.bmp, 
                Lineend.bmp, Lines.bmp, List.bmp, Netmask.bmp, 
                Network.bmp, Orgchart.bmp, Orgmask.bmp, 
                Orthoarw.bmp,Orthopth.bmp, Para.bmp, Paths.bmp, 
                Polyline.bmp, Rect.bmp, Rndrect.bmp, Scroller.bmp, 
                Select.bmp, Sndtobck.bmp, Spline.bmp, Text.bmp, 
                Textfld.bmp, Zorder.bmp


Other add-ons such as the Advanced Tools or the DLL and C Connect
should be installed in the vwnc30 directory.

02/02/98  py

